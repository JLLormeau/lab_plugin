from collections import namedtuple, defaultdict
from typing import List, Any, Tuple, Dict, Sequence
from logging import getLogger
import json
import sys
from ruxit.platform.platform_api import PlatformAPI, EntityResolverIfc, SelectedPlugins, PluginConfig, NonExistingPlugin
import ruxit.plugin_custom_device_reporter
from ruxit.package_utils.plugin_updater import PluginInfo
from ruxit.plugin_state_machine import PluginEngine
from ruxit.select_plugins import BaseActivationContext, selectors
from ruxit.remote.remote_plugin_engine import RemotePluginEngine
from ruxit.plugin_status_reporter import PluginFullStatus, PluginState
from ruxit.config_utils import PluginProperties
from pkg_resources._vendor.packaging import _structures

PluginInstanceConfig = namedtuple("PluginInstanceConfig", ["instanceId", "properties", "fastId"])

SupportAlertCreatorConfig = namedtuple("SupportAlertCreatorConfig",
                                                   ["metric", "info_label", "unit", "alert_callable", 
                                                    "default_value", "debug_flag"])

class RemotePluginConfigInfo:
    def __init__(self, plugin_name:str, config_id:int, plugin_instance_config:Dict[str,str], 
                 fast_id:Tuple[int,int], fast_checked:bool, enabled:bool, is_new:bool,
                 endpoint_name:str):
        self._plugin_name = plugin_name
        self._config_id = config_id
        self._plugin_instance_config = plugin_instance_config
        self._fast_id = fast_id
        self._fast_checked = fast_checked
        self._enabled = enabled
        self._is_new = is_new
        self._endpoint_name = endpoint_name
        self.disable_detected = False

    def __str__(self):
        return "plugin_name: {}; endpoint {}; config_id 0x{:x}; properties{}".format(
            self.plugin_name, self.endpoint_name, self.config_id, self.plugin_instance_config)
        
    @property
    def plugin_name(self)->str:
        return self._plugin_name

    @property
    def config_id(self)->int:
        return self._config_id

    @property
    def plugin_instance_config(self)->Dict[str,str]:
        return self._plugin_instance_config

    @property
    def fast_id(self)->Tuple[int,int]:
        return self._fast_id

    @property
    def is_fast_id(self)->bool:
        return len(self._fast_id) > 0
    
    @property
    def enabled(self)->bool:
        return self._enabled
    
    @property
    def fast_checked(self)->bool:
        return self._fast_checked;
    @fast_checked.setter
    def fast_checked(self, value:bool):
        self._fast_checked = value;
        
    @property
    def is_new(self)->bool:
        return self._is_new
    @is_new.setter
    def is_new(self, value:bool):
        self._is_new = value
        
    @property
    def fast_check_should_restart(self)->bool:
        return self.is_fast_id or self.fast_checked
    
    @property
    def endpoint_name(self)->str:
        return self._endpoint_name       

class RemoteActivationContext(namedtuple("BaseRemoteContext", ["config_id",
                                                               "endpoint_name",
                                                               "properties",
                                                               "enabled"])):
    __slots__= ()
    
    def __new__(cls, config_id, endpoint_name, properties, enabled):
        return super(RemoteActivationContext, cls).__new__(cls,
                                                           config_id = config_id,
                                                           endpoint_name = endpoint_name,
                                                           properties = properties,
                                                           enabled=enabled)
    
    def select_id(self, **kwargs):
        return self.meid
    
    def __repr__(self):
        return "{0}(config_id=0x{1:x}, endpoint={2}, properties={3}, enabled={4})"\
            .format(type(self).__name__, self.entity_id, self.endpoint_name, self.properties, self.enabled)
            
    @property
    def entity_id(self):
        return self.config_id
    @property
    def value(self):
        return self.config_id


class RemoteEntityResolver(EntityResolverIfc):
    def get_snapshot(self):
        return None

    def resolve(self, selector, **kwargs):
        return selector.select_id(
            process_snapshot=None,
            snapshot_by_process_type = defaultdict(list),
            snapshot_by_technology = defaultdict(list),
            docker_entity_map={},
            **kwargs
        )


class RemoteAPI(PlatformAPI):
    def __init__(self, external_api):
        self._external_api = external_api
        self._latest_plugin_configs = {}  # It stores the list of RemotePluginConfigInfo taken from Remote Plugin Agent
        self._plugin_dev_global_logger = getLogger("plugin_development.global")
        self._plugin_topology_reporter = ruxit.plugin_custom_device_reporter.PluginCustomDeviceReporter(
            self._external_api)
        self._entity_resolver = RemoteEntityResolver()
        self.updated = False

    @property
    def external_api(self):
        return self._external_api

    @property
    def entity_resolver(self):
        return self._entity_resolver

    def data_update(self) -> bool:
        try:
            configs_raw = self.external_api.get_latest_configs()
        except:
            self._plugin_dev_global_logger.exception("Unable to get latest configs")
            return

        configs = {}
        for plugin_name, plugin_config_info in configs_raw.items():
            for config_instance in plugin_config_info.pluginConfigProperties:
                try:
                    instanceId=config_instance[0]
                    plugin_json = json.loads(config_instance[1])
                    all_properties = plugin_json.get('properties')
                    configs[instanceId] = RemotePluginConfigInfo(
                        plugin_name=plugin_name,
                        config_id=instanceId,
                        plugin_instance_config=PluginProperties(all_properties),
                        fast_id=config_instance[2],
                        fast_checked=False,
                        enabled=config_instance[4],
                        is_new=False,
                        endpoint_name = config_instance[3]
                    )
                except Exception as ex:
                    self._plugin_dev_global_logger.exception(ex)
                    self._plugin_dev_global_logger.exception("Unable to parse config for plugin: %s" % plugin_name)
                    
        config_changed = len(configs) != len(self._latest_plugin_configs)
        contains_fast_config = False
        # Mark the changed configs with an update flag
        for (config_id, new_config) in configs.items():
            contains_fast_config |= config_id == 0

            old_corresponding_config = self._latest_plugin_configs.get(config_id)

            # compare two configs and mark them for update
            if old_corresponding_config:
                new_config.fast_checked = old_corresponding_config.fast_checked
                if new_config.plugin_instance_config != old_corresponding_config.plugin_instance_config:
                    self._plugin_dev_global_logger.info(f"Configuration update for plugin {new_config.plugin_name}: {config_id} "
                                                        f"enabled: {new_config.enabled}")
                    new_config.is_new = True
                    config_changed = True
                if new_config.enabled != old_corresponding_config.enabled:
                    self._plugin_dev_global_logger.info(f"Enabled changed for plugin {new_config.plugin_name}: {config_id} "
                                                        f"from: {new_config.enabled} to {new_config.enabled}")
                    new_config.is_new = True
                    config_changed = True
                    new_config.disable_detected = True
            else:
                self._plugin_dev_global_logger.info(f"Fresh config received for plugin {new_config.plugin_name}: {config_id} "
                                                    f"enabled: {new_config.enabled}")
                new_config.is_new = True
                config_changed = True

        old_fast_config = self._latest_plugin_configs.get(0);
        if (not contains_fast_config) and (old_fast_config):
            config_changed = True

        self._latest_plugin_configs = configs
        return config_changed


    @staticmethod
    def _get_plugin_info_by_name(plugin_metadata: List[PluginInfo], name: str) -> PluginInfo:
        return next((x for x in plugin_metadata if x.name == name), None)

    def select_plugins(self, plugin_engines: List[RemotePluginEngine],
                       plugin_metadata: List[PluginInfo]) -> SelectedPlugins:
        to_activate = []
        to_deactivate = []

        # for every engine, if it's not present in the config
        for plugin_engine in plugin_engines:
            cfg = self._latest_plugin_configs.get(plugin_engine.config_id)
            if not cfg or cfg.fast_check_should_restart or cfg.disable_detected:
                self._plugin_dev_global_logger.debug("deactivating" + str(plugin_engine.config_id))
                to_deactivate.append(plugin_engine)

        for (config_id, plugin_config_instance) in self._latest_plugin_configs.items():
            plugin_name = plugin_config_instance.plugin_name

            # Only pass configs that are updated
            if not plugin_config_instance.is_new:
                self._plugin_dev_global_logger.debug("Ignoring existing instance of %s" % plugin_name)
                continue

            plugin_info = self._get_plugin_info_by_name(plugin_metadata, plugin_name)
            if not plugin_info:
                self._plugin_dev_global_logger.warn("No metadata available for plugin %s" % plugin_name)
                continue

            config_id = plugin_config_instance.config_id
            self._plugin_dev_global_logger.debug("activating " + str(config_id))
            to_activate.append(
                (RemoteActivationContext(config_id,
                                         plugin_config_instance.endpoint_name,
                                         plugin_config_instance.plugin_instance_config,
                                         plugin_config_instance.enabled),
                 plugin_info)
            )

        return SelectedPlugins(to_activate, to_deactivate)

    
    def get_plugin_config(self, plugin_engine: RemotePluginEngine, plugin_metadata: List[PluginInfo]) -> PluginConfig:
        config_id = plugin_engine.get_entity_id()
        cfg = self._latest_plugin_configs.get(config_id)

        if cfg:
            cfg.fast_checked = cfg.is_fast_id
            return PluginConfig(cfg.plugin_instance_config, cfg.fast_id, cfg.enabled)
        else:
            return PluginConfig(None, 0, False)


    def get_not_existing_plugins(self, plugins: Sequence[RemotePluginEngine]) -> Sequence[NonExistingPlugin]:
        #return of plugin names with configuration and not created
        ids = {plugin.get_entity_id() for plugin in plugins}
        return [NonExistingPlugin(config.plugin_name, id, config.fast_id) 
                for id, config in self._latest_plugin_configs.items() 
                if id not in ids];

    
    def additional_report_step(self, plugin_engine: RemotePluginEngine):
        try:
            self._plugin_topology_reporter.report_devices(plugin_engine)
            plugin_engine._handle_limit_error()
        except Exception as error:
            exception_info = sys.exc_info()
            plugin_engine.set_full_status(PluginState.ERROR_UNKNOWN, exception_info)
            # clear up results and topology:
            plugin_engine.results_builder.reset_result()
            plugin_engine.topology_builder._groups = {}
            raise error

    
    def create_engine(self, plugin_info: PluginInfo, activation_context) -> Any:
        return RemotePluginEngine(
            remote_api = self,
            external_api=self._external_api,
            entity_resolver=self._entity_resolver,
            plugin_info=plugin_info,
            activation_context=activation_context,
        )

    @property
    def is_local(self) -> bool:
        return False
