import typing
from inspect import stack


class Murmur2:
    _MURMUR2_A_SEED = 0xe17a1465
    _m = 0xc6a4a7935bd1e995
    _r = 47

    @staticmethod
    def _from_little_endian(data: str, offset: int, count: int) -> int:
        v = 0
        for i in range(offset + count - 1, offset - 1, -1):
            v = v << 8
            v += ord(data[i])
        return v

    @staticmethod
    def _python_murmur(data: str) -> int:
        data_len = len(data)
        h = Murmur2._MURMUR2_A_SEED ^ (data_len * Murmur2._m);
        last = data_len % 8
        end = data_len - last
        for i in range(0, end, 8):
            k = Murmur2._from_little_endian(data, i, 8)
            k *= Murmur2._m
            k &= 0xffffffffffffffff
            k ^= k >> Murmur2._r
            # k ^= (k % 0x1000000000000000) >> Murmur._r # k ^= k >>> r
            k *= Murmur2._m
            k &= 0xffffffffffffffff
            h ^= k
            h *= Murmur2._m
            h &= 0xffffffffffffffff

        if last > 0:
            h ^= Murmur2._from_little_endian(data, end, last)
            h *= Murmur2._m;
            h &= 0xffffffffffffffff

        h ^= h >> Murmur2._r
        h *= Murmur2._m
        h &= 0xffffffffffffffff
        h ^= h >> Murmur2._r
        return h

    @staticmethod
    def initialize(external_api):
        pass

    def murmur2(self, data: str) -> int:
        return self._python_murmur(data)
