import logging, sys

logger = logging.getLogger(__name__)

def python_version_compatible()->bool:
    if sys.version_info < (3, 6):
        logger.error(
            "Python 3.6 required. Your Python interpreter is too old. Please consider upgrading."
        )
        return False
    return True
